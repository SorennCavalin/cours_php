<?php


/* autoload avant session pour eviter les problèmes de conversion */
require "autoload.php";
session_start();
include __DIR__ . "/functions.inc.php";
